from datetime import datetime
import speech_recognition as sr
import pyaudio
import pyttsx3
from pymongo import MongoClient

# MongoDB Connection URL
connectionString = "mongodb+srv://parthpoladiya:Parth28poladiya@cluster0.jd6ydhb.mongodb.net/test"
client = MongoClient(connectionString)

# Speech Engine initialization
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

# Menu
menu = {"mango boba tea": 120, "lychee boba tea": 100, "chocolate boba tea": 100, "thick cold coffee": 150,
        "strawberry boba tea": 100}

# Get Current Date and time
currentMonth = datetime.now().strftime("%b")
currentYear = datetime.now().strftime("%Y")
currentDay = datetime.now().strftime("%d")
currentTime = datetime.now().strftime("%H:%M:%S")

# Creating a Database for boba ordering
db = client['boba-tea']

# The current collection we are working on which calculated based on current month and year
collection_name = currentMonth + " " + currentYear
collection = db[collection_name]

list_of_collections = db.list_collection_names()  # Return a list of collections in db

bot_name = "Boba-Tea"


def speak(text, rate=200):
    engine.setProperty('rate', rate)
    engine.say(text)
    engine.runAndWait()


def listen():
    listener = sr.Recognizer()

    with sr.Microphone() as source:
        listener.pause_threshold = 2
        input_speech = listener.listen(source, timeout=3, phrase_time_limit=4)

    try:
        # speak("Recognizing command...")
        print(f"{bot_name}: Recognizing command...")

        query = listener.recognize_google(input_speech)  # language='en-IN'
        print(f"You: {query}")

    except Exception as exception:
        print(f"{bot_name}: I did not catch that. Please try again")
        speak("I did not catch that. please try again")
        print(exception)
        return 'None'
    return query


def insertDocument(customerName, customerAddress, orderItem, orderBill, quantity):
    if collection_name in list_of_collections:
        orderid = collection.count_documents({}) + 1
        orderDetails = {"OrderId": orderid,
                        "OrderItems": orderItem,
                        "Quantity": quantity,
                        "OrderBill": orderBill,
                        "OrderDay": currentDay,
                        "OrderTime": currentTime,
                        "CustomerName": customerName,
                        "CustomerAddress": customerAddress}
        collection.insert_one(orderDetails)


def placeOrder():
    print(f"{bot_name}: Please select your order from the menu i say")
    speak("Please select your order from the menu i say")
    for item, price in menu.items():
        speak(f"Item Name {item}")
        print(f"Iten name: {item} \t Price: {price}")

    orderItem = listen().lower()

    if orderItem in menu.keys():
        print(f"{bot_name}: Do you want to order {orderItem}?")
        speak(f"Do you want to order {orderItem}?")
        orderConfirmation = listen().lower()
        if 'yes' in orderConfirmation:
            print(f"You: {orderConfirmation}")
            speak(f"How many {orderItem} do you want to order?")
            print(f"{bot_name}: How many {orderItem} do you want to order?")
            quantity = listen().lower()
            itemQuantity = int(quantity)
            speak("Please tell me your name")
            print(f"{bot_name}: Please tell me your name")
            customerName = listen().lower()
            speak("Please tell me the area where you live")
            print(f"{bot_name}: Please tell me the area where you live")
            customerAddress = listen().lower()
            orderBill = menu.get(orderItem)*itemQuantity
            speak(f"Your order is confirmed and will be delivered to you shortly. Please pay {orderBill} rupees to our "
                  f"delivery executive. Thank you for ordering with us")
            print(
                f"{bot_name}: Your order is confirmed and will be delivered to you shortly. Please pay {orderBill} rupees to our "
                f"delivery executive. Thank you for ordering with us")
            insertDocument(customerName, customerAddress, orderItem, orderBill, itemQuantity)
            exit()
        else:
            placeOrder()
    else:
        speak("We don't serve that item")
        print(f"{bot_name}: We don't serve that item")
        placeOrder()


def modifyOrder():
    speak("Please tell me your order id")
    print(f"{bot_name}: Please tell me your order id")
    orderId = listen()

    speak("Please select your order from the menu i say")
    print(f"{bot_name}: Please select your order from the menu i say")
    for item, price in menu.items():
        speak(f"Item Name {item}")
        print(f"Item name: {item} \t Price: {price}")

    orderItem = listen().lower()

    if orderItem in menu.keys():
        speak(f"Do you want to order {orderItem}?")
        print(f"{bot_name}: Do you want to order {orderItem}?")
        orderConfirmation = listen().lower()
        if 'yes' in orderConfirmation:
            orderBill = menu.get(orderItem)
            speak(f"Your order is confirmed and will be delivered to you shortly. Please pay {orderBill} rupees to our "
                  f"delivery executive. Thank you for ordering with us")
            print(
                f"{bot_name}: Your order is confirmed and will be delivered to you shortly. Please pay {orderBill} rupees to our "
                f"delivery executive. Thank you for ordering with us")
            collection.update_one({"OrderId": int(orderId)}, {"$set": {"OrderItems": orderItem}})
            exit()
        else:
            modifyOrder()
    else:
        speak("We don't serve that item")
        print(f"{bot_name}: We don't serve that item")
        placeOrder()


def orderStatus():
    speak("Please tell me your order id")
    print(f"{bot_name}: Please tell me your order id")
    orderId = listen()
    try:
        specificOrder = collection.find_one({"OrderId": int(orderId)}, {'_id': 0, 'OrderId': 1,
                                                                        'OrderItems': 1, 'Quantity': 1, 'OrderBill': 1, 'OrderDay': 1,
                                                                        'OrderTime': 1,
                                                                        'CustomerName': 1, 'CustomerAddress': 1})
    except Exception as exception:
        print(exception)
        speak(f"{bot_name}: Invalid Order Id")
        speak("Invalid Order Id")
        orderStatus()

    print(f"{bot_name}: {specificOrder}")
    speak(specificOrder)
    exit()
