from datetime import datetime
import speech_recognition as sr
import pyaudio
import pyttsx3
from pymongo import MongoClient

# MongoDB Connection URL
connectionString = "mongodb+srv://parthpoladiya:Parth28poladiya@cluster0.jd6ydhb.mongodb.net/test"
client = MongoClient(connectionString)

# Speech Engine initialization
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

# Menu
menu = {"mango boba tea": 120, "lychee boba tea": 100, "chocolate boba tea": 100, "thick cold coffee": 150,
        "strawberry boba tea": 100}

# Get Current Date and time
currentMonth = datetime.now().strftime("%b")
currentYear = datetime.now().strftime("%Y")
currentDay = datetime.now().strftime("%d")
currentTime = datetime.now().strftime("%H:%M:%S")

# Creating a Database for boba ordering
db = client['boba-tea']

# The current collection we are working on which calculated based on current month and year
collection_name = currentMonth + " " + currentYear
collection = db[collection_name]

list_of_collections = db.list_collection_names()  # Return a list of collections in 'test_db'


def speak(text, rate=200):
    engine.setProperty('rate', rate)
    engine.say(text)
    engine.runAndWait()


def insertDocument(customerName, customerAddress, orderItem, orderBill):
    if collection_name in list_of_collections:
        orderid = collection.count_documents({}) + 1
        orderDetails = {"OrderId": orderid,
                        "OrderItems": orderItem,
                        "OrderBill": orderBill,
                        "OrderDay": currentDay,
                        "OrderTime": currentTime,
                        "CustomerName": customerName,
                        "CustomerAddress": customerAddress}
        collection.insert_one(orderDetails)


def placeOrder():
    speak("Please select your order from the menu i say")
    for item, price in menu.items():
        speak(f"Item Name {item}")
        print(f"Iten name: {item} \t Price: {price}")

    orderItem = listen().lower()

    if orderItem in menu.keys():
        speak(f"Do you want to order {orderItem}?")
        orderConfirmation = listen().lower()
        if 'yes' in orderConfirmation:

            speak("Please tell me your name")
            customerName = listen().lower()
            speak("Please tell me the area where you live")
            customerAddress = listen().lower()
            orderBill = menu.get(orderItem)
            speak(f"Your order is confirmed and will be delivered to you shortly. Please pay {orderBill} rupees to our "
                  f"delivery executive. Thank you for ordering with us")
            insertDocument(customerName, customerAddress, orderItem, orderBill)
            exit()
        else:
            placeOrder()
    else:
        speak("We don't serve that item")
        placeOrder()


def orderStatus():
    speak("Please tell me your order id")
    orderId = listen()
    try:
        specificOrder = collection.find_one({"OrderId": int(orderId)}, {'_id': 0, 'OrderId': 1,
                                                                        'OrderItems': 1, 'OrderBill': 1, 'OrderDay': 1,
                                                                        'OrderTime': 1,
                                                                        'CustomerName': 1, 'CustomerAddress': 1})
    except Exception as exception:
        print(exception)
        speak("Invalid Order Id")
        orderStatus()

    print(specificOrder)
    speak(specificOrder)
    exit()


def listen():
    listener = sr.Recognizer()

    with sr.Microphone() as source:
        listener.pause_threshold = 2
        input_speech = listener.listen(source, timeout=3, phrase_time_limit=4)

    try:
        # speak("Recognizing command...")
        print("Recognizing command...")

        query = listener.recognize_google(input_speech)  # language='en-IN'
        print(f"The input speech was {query}")

    except Exception as exception:
        print("I did not catch that. Please try again")
        speak("I did not catch that. please try again")
        print(exception)
        return 'None'
    return query


def modifyOrder():
    speak("Please tell me your order id")
    orderId = listen()

    speak("Please select your order from the menu i say")
    for item, price in menu.items():
        speak(f"Item Name {item}")
        print(f"Item name: {item} \t Price: {price}")

    orderItem = listen().lower()

    if orderItem in menu.keys():
        speak(f"Do you want to order {orderItem}?")
        orderConfirmation = listen().lower()
        if 'yes' in orderConfirmation:
            orderBill = menu.get(orderItem)
            speak(f"Your order is confirmed and will be delivered to you shortly. Please pay {orderBill} rupees to our "
                  f"delivery executive. Thank you for ordering with us")
            collection.update_one({"OrderId": int(orderId)}, {"$set": {"OrderItems": orderItem}})
            exit()
        else:
            modifyOrder()
    else:
        speak("We don't serve that item")
        placeOrder()


# Main Loop
if __name__ == '__main__':

    while True:
        print("Welcome to Boba Tea. How can i help you?")
        speak("Welcome to Boba Tea. How can i help you?")

        query = listen().lower()
        print(query)

        if "place an order" in query:
            placeOrder()
        elif "change" in query:
            modifyOrder()
        elif "order details" in query:
            orderStatus()
        elif "cancel" in query:
            speak("Order once placed cannot be canceled")
        elif "payment" in query:
            speak("Order once placed cannot be canceled")
        else:
            speak("This query is out of my capability. Our executive will call you shortly")
            print("This query is out of my capability. Our executive will call you shortly")
            exit()
