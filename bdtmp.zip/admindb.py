from pymongo import MongoClient
# MongoDB Connection URL
connectionString = "mongodb+srv://parthpoladiya:Parth28poladiya@cluster0.jd6ydhb.mongodb.net/test"
client = MongoClient(connectionString)


db = client['boba-tea']
list_of_collections = db.list_collection_names()


def chooseCollection():
    i=0
    print("Choose a collection from the given list")
    for c in list_of_collections:
        i=i+1
        print(f"{i}. {c}")
    choice = int(input()) -1
    collection_name = list_of_collections[choice]
    collection = db[collection_name]
    return collection


def displayAll():

    collection =chooseCollection()
    allOrder = collection.find()
    for order in allOrder:
        print(order)

def calculateRevenue():
    collection = chooseCollection()
    revenue = collection.aggregate([{"$group":{"_id":"null","Revenue":{"$sum":"$OrderBill"}}}])
    for r in revenue:
        print(f"The revenue for the choosen collection is {r['Revenue']}")

def AverageOrderValue():
    collection = chooseCollection()
    output = collection.aggregate([{"$group":{"_id":"null","AverageOrderValue":{"$avg":"$OrderBill"}}}])
    for o in output:
        print(f"Average order value is {o['AverageOrderValue']}")

def minMaxValue():
    collection = chooseCollection()
    output = collection.aggregate([{"$group":{"_id":"null","MinOrderValue":{"$min":"$OrderBill"},"MaxOrderValue":{"$max":"$OrderBill"}}}])
    for o in output:
        print(f"Min order value is {o['MinOrderValue']}")
        print(f"Max order value is {o['MaxOrderValue']}")



while True:
 choice = int(input("1. Display all orders\n2. Calculate Revenue\n3. Average Order Value\n4. Minimum and Maximum Order Value\n5. Exit"))

 if choice == 1:
     displayAll()
 elif choice == 2:
     calculateRevenue()
 elif choice == 3:
     AverageOrderValue()
 elif choice == 4:
     minMaxValue()
 else:
     exit()






